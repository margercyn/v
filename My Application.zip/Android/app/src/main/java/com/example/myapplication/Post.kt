package com.example.myapplication

data class Post(var titleImage: Int, var heading: String)
